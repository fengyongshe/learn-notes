package com.sun.messaging.jmq.jmsclient.runtime.impl;

import javax.jms.JMSException;

import com.sun.messaging.jmq.jmsclient.runtime.BrokerInstance;
import com.sun.messaging.jmq.jmsservice.DirectBrokerConnection;

public interface DirectBrokerInstance extends BrokerInstance {

	public DirectBrokerConnection createDirectConnection() throws JMSException;
		
}
