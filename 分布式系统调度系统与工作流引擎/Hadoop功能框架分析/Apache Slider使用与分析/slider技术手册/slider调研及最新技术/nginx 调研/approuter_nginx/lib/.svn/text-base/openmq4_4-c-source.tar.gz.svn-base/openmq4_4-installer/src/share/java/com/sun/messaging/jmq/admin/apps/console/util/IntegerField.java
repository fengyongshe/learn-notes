/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 2000-2009 Sun Microsystems, Inc. All rights reserved. 
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License ("CDDL") (collectively, the "License").  You may
 * not use this file except in compliance with the License.  You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or mq/legal/LICENSE.txt.  See the License for the specific language
 * governing permissions and limitations under the License.
 * 
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at mq/legal/LICENSE.txt.  Sun designates
 * this particular file as subject to the "Classpath" exception as provided by
 * Sun in the GPL Version 2 section of the License file that accompanied this
 * code.  If applicable, add the following below the License Header, with the
 * fields enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 * 
 * Contributor(s):
 * 
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or  to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright holder. 
 */

/*
 * @(#)IntegerField.java	1.5 06/27/07
 */ 

package com.sun.messaging.jmq.admin.apps.console.util;

import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import javax.swing.JTextField;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public class IntegerField extends JTextField {
    
    //*****************************************************************
    // Constructors
    
    public IntegerField(long min, long max, String text) {
	this(min, max, text, 0);
    }

    public IntegerField(long min, long max, int columns) {
	this(min, max, null, columns);
    }

    public IntegerField(long min, long max, 
			String text, int columns) {
	super(new IntegerDocument(min, max), text, columns);
    }
}

//*************************************************************************
// IntegerDocument class

class IntegerDocument extends PlainDocument {
    long min;
    long max;

    //*********************************************************************
    // Constructors
    
    public IntegerDocument(long min, long max) {
	this.min = min;
	this.max = max;
    }
    
    //*********************************************************************
    // Validation routines

    public void insertString(int offset, String str, AttributeSet a)
	 throws BadLocationException 
    {
	// Validate each char in str checking if in '0' .. '9'.
	// If the min value is < 0, then allow a '-' only in the
	// first position.

	for (int i=0; i<str.length(); i++) {
	    int keyCode = (int)str.charAt(i);
	    if (keyCode < KeyEvent.VK_0 || keyCode > KeyEvent.VK_9) {
		// keyCode 45 is the '-' char.
		if (!(min < 0 && offset == 0 && keyCode == 45)) {
		    Toolkit.getDefaultToolkit().beep();
		    return;
		}
	    }
	}
	
	// Validate the entire string in text field making
	// sure it's within range.

	String sval = getText(0, getLength());
	sval = sval.substring(0, offset) + str +
	    sval.substring(offset, sval.length());
	// Max digits for a number to fit in a type long.
	// And also make sure two '-'s weren't entered.
	if (sval.length() > 18 || sval.startsWith("--")) {
	    Toolkit.getDefaultToolkit().beep();
	    return;
	} else if (!sval.equals("-") && sval.length() > 0) {
	    // Evaluate only if it's not a single '-' char.
	    long ival = Long.valueOf(sval).longValue();
	    if (ival < min || ival > max) {
		Toolkit.getDefaultToolkit().beep();
		return;
	    }
	}
	
	// Accept the input.
	super.insertString(offset, str, a);
    }
}







